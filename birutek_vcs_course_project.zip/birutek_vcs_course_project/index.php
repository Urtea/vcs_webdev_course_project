<?php
require __DIR__.'/app.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Snow | Digital Agency</title>
    <meta name="description" content="Digital agency - design, photo, web">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/favicon.png">
    <!-- STYLES: start -->
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i%7cWork+Sans:400,500,700" rel="stylesheet" type="text/css">
    
    <!-- my stylesheet -->
    <link rel="stylesheet" href="css/style.css">
    <!-- STYLES: end -->
</head>

<body>
    <!-- HEADER: start -->
    <header class="header-box">
            <div class="container">
                <nav class="navbar">
                    <a class="nav-logo" href="index.php"><img src="images/logo.png" alt=""></a>
                    <div class="nav-links">
                        <a href="#about">About</a>
                        <a href="#portfolio">Portfolio</a>
                        <a href="#contact">Contact</a>
                        <a class="icon">
                           <img src="images/icons/menu.png" width="45" id="myBtn">
                        </a>
                    </div>
                </nav>
            </div>
        <!-- MODAL MENU -->
        <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="top-margin"></div>
            <a href="#about" id="about1">ABOUT</a>
            <a href="#portfolio" id="portfolio1">PORTFOLIO</a>
            <a href="#contact" id="contact1">CONTACT</a>
        </div>
        </div>
    </header>
    <!-- HEADER: end -->
    
    <!-- MAIN: start -->
    <div class="main"> 

        <!-- BANNER: start -->
        <div class="banner-box">
            <div class="container">
                <div class="banner-content" id="content-modal">
                    <h4>New Branding Agency</h4>
                    <h1 id="bcont-big">We are about to change the way
                        <br>
                        <em class="fweight400">you publish on the web</em>
                    </h1>
                    <h1 id="bcont-small">We are about to
                        <br>
                        change the way
                        <br>
                        <em class="fweight400">you publish on the web</em>
                    </h1>
                </div>
            </div>
        </div>
        <!-- BANNER: end -->

        <!-- ABOUT: start -->
        <div class="about-box">
            <div class="container">
                <a name="about"></a>
                <div class="about-content">
                    <h2>About Our Agency</h2>
                    <p>We are a new design studio based in USA. We have over 20 years of combined experience, and know a thing or two about designing websites and mobile apps. Clever use of technology and lean processes enable us to work faster and smarter.
                    <p>We are a new design studio based in USA. We have over 20 years of combined experience, and know a thing or two about designing websites and mobile apps. Clever use of technology and lean processes enable us to work faster and smarter.
                    </p>
                    <img src="images/about-me-signature.png" alt="" class="about-img">
                </div>
            </div>
        </div>
        <!-- ABOUT: end -->

        <!-- FEATURES: start -->
        <div class="features-box">
            <div class="container">
                <div class="f-box">
                    <div class="f-icon">
                        <img class="f-icon-fit" src="images/icons/suitcase.png">
                    </div>
                    <div class="f-content">
                        <div class="f-title">548</div>
                        <div class="f-text">Projects Completed</div>
                    </div>
                </div>

                <div class="f-box">
                    <div class="f-icon">
                        <img class="f-icon-fit" src="images/icons/clock.png">
                    </div>
                    <div class="f-content">
                        <div class="f-title">1465</div>
                        <div class="f-text">Working Hours</div>
                    </div>
                </div>

                <div class="f-box">
                    <div class="f-icon">
                        <img class="f-icon-fit" src="images/icons/favourite-star.png">
                    </div>
                    <div class="f-content">
                        <div class="f-title">612</div>
                        <div class="f-text">Positive Feedbacks</div>
                    </div>
                </div>

                <div class="f-box">
                    <div class="f-icon">
                        <img class="f-icon-fit" src="images/icons/heart.png">
                    </div>
                    <div class="f-content">
                        <div class="f-title">735</div>
                        <div class="f-text">Happy Clients</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FEATURES: end -->

        <!-- PORTFOLIO: start -->
        <div class="portfolio-box">
            <div class="container">
                <a name="portfolio"></a>
                <div class="projects-content">
                    <h2>Best Projects</h2>
                    <p>Donec orci sem, pretium ac dolor et, faucibus faucibus mauris. Etiam, pellentesque faucibus. Vestibulum gravida volutpat ipsum non ultrices. Etiam, pellentesque faucibus. Vestibulum gravida volutpat ipsum non ultrices.</p>
                </div>

                <div class="projects-box">

                    <div class="portfolio-img" id="project01">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project02">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project03">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project04">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project05">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project06">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project07">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project08">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                    <div class="portfolio-img" id="project09">
                        <a href="index.php" target="_top"><div class="img-text"><p>Read more</p></div></a>
                    </div>

                </div>
            </div>
        </div>
        <!-- PORTFOLIO: end -->

        <!-- REVIEWS: start -->
        <div class="reviews-box">
            <div class="container">
                <div class="mySlides fading">
                    <blockquote class="review-quote">
                        <p>Outstanding job and exceeded all expectations. It was a pleasure to work with them on a sizable first project and am looking forward to start the next one asap.</p>
                        <cite>Michael Hopkins</cite>
                    </blockquote>
                </div>    
                <div class="mySlides fading">
                    <blockquote class="review-quote">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...</p>
                        <cite>Thomas Harris</cite>
                    </blockquote>
                </div>
                <div class="mySlides fading">
                    <blockquote class="review-quote">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...</p>
                        <cite>Liz Belleville</cite>
                    </blockquote>
                </div>
                <br>
                <div style="text-align: center">
                    <span class="dot" onclick="currentSlide(1)"></span>
                    <span class="dot" onclick="currentSlide(2)"></span>
                    <span class="dot" onclick="currentSlide(3)"></span>
                </div>
            </div>
        </div>
        <!-- REVIEWS: end -->

        <!-- PARTNERS: start -->
        <div class="partners-box">
            <div class="container">
                <div class="bg-white">
                    <div class="container-partners">
                        <div class="nk-box-1">
                            <img src="images/partner_logos/logo_1.png" alt="Partner 1" class="partner-img">
                        </div>
                        <div class="nk-box-1">
                            <img src="images/partner_logos/logo_2.png" alt="Partner 2" class="partner-img">
                        </div>
                        <div class="nk-box-1">
                            <img src="images/partner_logos/logo_1.png" alt="Partner 3" class="partner-img">
                        </div>
                        <div class="nk-box-1">
                            <img src="images/partner_logos/logo_2.png" alt="Partner 4" class="partner-img">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- PARTNERS: end -->

        <!-- CONTACT: start -->
        <div class="contact-box">
            <div class="container" id="contact">
                <a name="contact"></a>
                <!-- INFO: start -->
                
                <div class="contact-info">  
                    <h2>Contact Info:</h2>
                    <p>Praesent interdum congue mauris, et fringilla lacus pel vitae. Quisque nisl mauris, aliquam eu ultrices vel, conse vitae sapien at imperdiet risus. Quisque cursus risus id. fermentum, in auctor quam consectetur.</p>
                    <ul>                        
                        <li>
                            <strong>Address:</strong> <a href="https://www.google.com/maps/place/Rightpoint/@34.0179656,-118.4996293,16z/data=!4m8!1m2!2m1!1sLos+Angeles,+digital+agency!3m4!1s0x0:0x7c4752f10edd48df!8m2!3d34.0149268!4d-118.4946567" target="_blank">10111 Santa Monica Boulevard, LA</a></li>
                        <li>
                            <strong>Phone:</strong> <a href="tel:+4412345678">+44 123 456 78</a></li>
                        <li>
                            <strong>Email:</strong> <a href="mailto:info@agency.com">info@agency.com</a></li>
                        <li>
                            <strong>Fax:</strong> <a href="tel:+44987654321">+44 987 654 321</a></li>
                    </ul>
                </div>
                <!-- INFO: end -->

                <!-- FORM: start -->
                <div class="contact-form">
                   <form action="#" method="post" onsubmit="alert('Thank you for your message!');">
                        <div class="cform">
                            <input type="text" class="form-input" name="name" placeholder="Your Name" required autocomplete="off">
                            <input type="email" class="form-input" name="email" placeholder="Your Email" required autocomplete="off">
                            <input type="text" class="form-input" name="title" placeholder="Your Title" required autocomplete="off">
                            <textarea class="form-input" name="message" rows="8" placeholder="Your Message" required></textarea>
                       </div>                  
                       <button class="contact-button" name="submit" type="submit">Send Message</button>
                    </form>
                </div>
            </div>
        </div> 
        <!-- CONTACT: end -->
    </div>
    <!-- MAIN: end -->
    
    <!-- FOOTER: start -->
    <footer class="footer-box">
        <div class="container">
            <div class="footer-social">
                <ul>
                    <li><a href="https://www.twitter.com" target="_blank"><img src="images/social_icons/twitter-logo.png" class="icon"></a></li>
                    <li><a href="https://www.facebook.com" target="_blank"><img src="images/social_icons/facebook-circular-logo.png" class="icon"></a></li>
                    <li><a href="https://www.dribbble.com" target="_blank"><img src="images/social_icons/dribbble-logo.png" class="icon"></a></li>
                    <li><a href="https://www.instagram.com" target="_blank"><img src="images/social_icons/instagram-logo.png" class="icon"></a></li>
                </ul>
            </div>

            <div class="footer-text">
                <p><?php echo date('Y'); ?> &copy; Design by Snow</p>
            </div>
        </div>
    </footer>
    <!-- FOOTER: end -->
    
    <!-- SCRIPTS -->    
    <script src="scripts/custom.js"></script>
</body>
</html>